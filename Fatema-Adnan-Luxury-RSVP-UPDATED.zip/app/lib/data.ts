export const wedding = {
  bride: 'Fatema',
  brideParents: 'Mr. Fakhruddin & Mrs. Insiyah Depalpurwala',
  groom: 'Adnan',
  groomParents: 'Late Mr. Fakhruddin & Mrs. Ummesalma Saifee',
  date: '13 November 2026',
  day: 'Thursday',
  hijri: '4 Jamada Al Ukhra',
  time: '8:00 PM',
  venue: 'Masakin-e-Safiyah Jamatkhana',
  nikahLine: 'The Nikah has been solemnized in the hands of Shehzada Idris Bhai Saheb D.M.',
  families: 'Depalpurwala & Saifee Families',
  address: 'Masakin-e-Safiyah Jamatkhana',
  mapsQuery: 'Masakin-e-Safiyah Jamatkhana',
  note: 'No grandparents or separate function names are legible on the supplied wedding-details image; none are invented here.'
} as const;
