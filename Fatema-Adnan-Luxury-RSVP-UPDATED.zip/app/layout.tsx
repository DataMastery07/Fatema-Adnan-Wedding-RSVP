import './globals.css';
export const metadata={title:'Fatema & Adnan | Wedding Celebration',description:'A royal wedding invitation for Fatema & Adnan.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body className="grain">{children}</body></html>}
