'use client';
import {motion} from 'framer-motion';
export default function Loader(){return <motion.div initial={{opacity:1}} animate={{opacity:0,pointerEvents:'none'}} transition={{delay:1.1,duration:.7}} className="fixed inset-0 z-[100] grid place-items-center bg-[#FFFEF9]"><motion.div initial={{scale:.7,opacity:0}} animate={{scale:1,opacity:1}} transition={{duration:.8}} className="text-center"><div className="text-6xl gold-text font-display">F & A</div><div className="mt-3 tracking-[.4em] text-xs text-[#0A4D3C]">FATEMA • ADNAN</div></motion.div></motion.div>}
