'use client';
import {motion} from 'framer-motion';
export default function Petals(){return <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden">{Array.from({length:14}).map((_,i)=><motion.span key={i} className="absolute h-2 w-3 rounded-full bg-[#d9a0a0]/45" style={{left:`${(i*71)%100}%`,top:`-${10+i}%`,rotate:i*17}} animate={{y:'115vh',x:[0,(i%2?40:-40),10],rotate:[0,180,320]}} transition={{duration:12+i%5,repeat:Infinity,delay:i*.7,ease:'linear'}} />)}</div>}
