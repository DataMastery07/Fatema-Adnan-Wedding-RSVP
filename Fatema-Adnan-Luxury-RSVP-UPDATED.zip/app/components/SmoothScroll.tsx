'use client';
import {useEffect} from 'react';
export default function SmoothScroll(){useEffect(()=>{let lenis:any;let raf:number;import('lenis').then(({default:Lenis})=>{lenis=new Lenis({duration:1.15,smoothWheel:true});const loop=(t:number)=>{lenis?.raf(t);raf=requestAnimationFrame(loop)};raf=requestAnimationFrame(loop)});return()=>{cancelAnimationFrame(raf);lenis?.destroy()}},[]);return null}
