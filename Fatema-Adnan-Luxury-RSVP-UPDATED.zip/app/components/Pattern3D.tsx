'use client';
import {Canvas,useFrame} from '@react-three/fiber';
import {Float,OrbitControls,Environment} from '@react-three/drei';
import {useRef} from 'react';
function Arch(){const ref=useRef<any>();useFrame((_,d)=>{if(ref.current)ref.current.rotation.y+=d*.035});return <mesh ref={ref} rotation={[Math.PI/2,0,0]}><torusGeometry args={[2.2,.035,16,96,Math.PI]} /><meshStandardMaterial color="#D4AF37" metalness={.9} roughness={.25}/></mesh>}
export default function Pattern3D(){return <div className="absolute inset-0 opacity-35"><Canvas camera={{position:[0,0,6],fov:42}}><ambientLight intensity={1}/><directionalLight position={[2,3,4]} intensity={2}/><Environment preset="studio"/><Float speed={1.2} rotationIntensity={.15} floatIntensity={.35}><Arch/></Float><OrbitControls enableZoom={false} enablePan={false} autoRotate={false}/></Canvas></div>}
