'use client';
import {useEffect,useState} from 'react';
export default function Cursor(){const [p,setP]=useState({x:-50,y:-50});useEffect(()=>{const f=(e:MouseEvent)=>setP({x:e.clientX,y:e.clientY});window.addEventListener('mousemove',f);return()=>window.removeEventListener('mousemove',f)},[]);return <div className="pointer-events-none fixed z-[90] hidden md:block" style={{left:p.x,top:p.y,transform:'translate(-50%,-50%)'}}><div className="h-3 w-3 rounded-full border border-[#D4AF37] shadow-[0_0_18px_#D4AF37]"/></div>}
