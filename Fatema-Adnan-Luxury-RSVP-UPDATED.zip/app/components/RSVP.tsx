'use client';
import {FormEvent,useState} from 'react';

type State='idle'|'loading'|'ok'|'error';
export default function RSVP(){
 const [state,setState]=useState<State>('idle');
 async function submit(e:FormEvent<HTMLFormElement>){
  e.preventDefault(); setState('loading');
  const form=e.currentTarget; const data=Object.fromEntries(new FormData(form).entries());
  try{const r=await fetch('/api/rsvp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); if(!r.ok) throw new Error(); setState('ok'); form.reset();}
  catch{setState('error');}
 }
 return <div className="rsvp-shell">
  <div className="rsvp-card">
   <div className="rsvp-topline"><span/> KINDLY RESPOND <span/></div>
   <h3 className="rsvp-title">Your Presence Matters</h3>
   <p className="rsvp-subtitle">Please share your response and a Dua for Fatema & Adnan.</p>
   <form onSubmit={submit} className="space-y-5">
    <div className="grid sm:grid-cols-2 gap-5">
     <label className="lux-label">Your Name<input required name="name" autoComplete="name" placeholder="Enter your name" /></label>
     <label className="lux-label">Relationship<input required name="relationship" placeholder="Family • Friend • Colleague" /></label>
     <label className="lux-label">Number of Guests<select name="guests" defaultValue="1">{[1,2,3,4,5,6,7,8].map(n=><option key={n}>{n}</option>)}</select></label>
     <label className="lux-label">Will you be joining us?<select name="attending" defaultValue="Yes"><option>Yes, with pleasure</option><option>Regretfully, no</option></select></label>
    </div>
    <label className="lux-label">Your Dua / Wishes<textarea required name="wishes" rows={5} placeholder="Write a heartfelt Dua or message for the couple…"/></label>
    <button disabled={state==='loading'} className="rsvp-submit"><span>{state==='loading'?'Sending your RSVP…':'Confirm RSVP'}</span><b>→</b></button>
    {state==='ok'&&<div className="status success">Your RSVP has been received with thanks. ✦</div>}
    {state==='error'&&<div className="status error">We could not save your RSVP. Please try again.</div>}
   </form>
  </div>
 </div>
}
