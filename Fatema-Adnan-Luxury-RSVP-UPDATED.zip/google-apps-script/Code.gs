const SHEET_NAME = 'RSVP';
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sheet.getLastRow() === 0) sheet.appendRow(['Timestamp','Name','Relationship','Guests','Attending','Dua / Wishes']);
    sheet.appendRow([new Date(), data.name || '', data.relationship || '', data.guests || '', data.attending || '', data.wishes || '']);
    return json({ok:true});
  } catch (err) { return json({ok:false,error:String(err)}); }
}
function doGet(){return json({ok:true,service:'Fatema & Adnan RSVP'});}
function json(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
